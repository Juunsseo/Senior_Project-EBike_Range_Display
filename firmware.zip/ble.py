from micropython import const
import asyncio
import aioble
import bluetooth
import struct

rx_value = None
from display import sensor_data   # ADD THIS at top of ble.py

# =========================================================
# BLE OFFICIAL SIG UUIDs
# =========================================================

# Battery Service (standard)
_BAT_SERV_UUID = bluetooth.UUID(0x180F)

# Standard Characteristics
_VOLTAGE_UUID       = bluetooth.UUID(0x2B18)  # Voltage (uint16, mV)
_CURRENT_UUID       = bluetooth.UUID(0x2704)  # Electric Current (sint16, mA)
_POWER_UUID         = bluetooth.UUID(0x2726)  # Power (uint16, W)
_BATTERY_LEVEL_UUID = bluetooth.UUID(0x2A19)  # Battery Level (%)
_TEMPERATURE_UUID   = bluetooth.UUID(0x2A6E)  # Temperature (sint16, 0.01°C)

_RX_UUID = bluetooth.UUID("12345678-1234-5678-1234-56789abcdef0")	#data from phone

# =========================================================
# Advertising config
# =========================================================

_ADV_APPEARANCE_GENERIC_SENSOR = const(1344)
_ADV_INTERVAL_US = const(250_000)

# =========================================================
# BLE Services + Characteristics
# =========================================================

battery_service = aioble.Service(_BAT_SERV_UUID)

voltage_ch = aioble.Characteristic(
    battery_service, _VOLTAGE_UUID, read=True, notify=True
)

current_ch = aioble.Characteristic(
    battery_service, _CURRENT_UUID, read=True, notify=True
)

power_ch = aioble.Characteristic(
    battery_service, _POWER_UUID, read=True, notify=True
)

battery_ch = aioble.Characteristic(
    battery_service, _BATTERY_LEVEL_UUID, read=True, notify=True
)

temperature_ch = aioble.Characteristic(
    battery_service, _TEMPERATURE_UUID, read=True, notify=True
)

rx_ch = aioble.Characteristic(
    battery_service,
    _RX_UUID,
    read=False,
    write=True,        # <-- allow phone → Pico write
    notify=False
)

aioble.register_services(battery_service)

# =========================================================
# Whitelist: "trust first phone, block others"
# =========================================================

# (addr_type, addr_bytes) of the one "owner" device.
_authorized_peer = None  # type: tuple[int, bytes] | None


def _format_peer(dev) -> tuple[int, bytes]:
    """Return a stable representation (addr_type, addr_bytes)."""
    return (dev.addr_type, bytes(dev.addr))


# =========================================================
# API for main.py to push sensor data into BLE
# =========================================================

def ble_update(voltage: float, current: float, power: float,
               temperature: float, battery_level: int) -> None:
    """
    Update all BLE characteristics and notify any connected central.

    voltage      : Volts (float)
    current      : Amps  (float)
    power        : Watts (float)
    temperature  : Deg C (float)
    battery_level: Percent 0–100 (int)
    """
    # Standard Bluetooth SIG encodings:

    # VOLTAGE (0x2B18) — uint16, mV
    v_mv = int(voltage * 1000)
    voltage_ch.write(struct.pack("<H", v_mv), send_update=True)

    # CURRENT (0x2704) — sint32, uA (client divides by 1000 -> mA)
    i_ua = int(current * 1_000_000)
    if i_ua < -0x80000000:
        i_ua = -0x80000000
    if i_ua > 0x7FFFFFFF:
        i_ua = 0x7FFFFFFF
    current_ch.write(struct.pack("<i", i_ua), send_update=True)

    # POWER (0x2726) — uint32, mW (client divides by 1000 -> W)
    p_mw = int(power * 1000)
    if p_mw < 0:
        p_mw = 0
    if p_mw > 0xFFFFFFFF:
        p_mw = 0xFFFFFFFF
    power_ch.write(struct.pack("<I", p_mw), send_update=True)

    # TEMPERATURE (0x2A6E) — sint16, 0.01°C
    t_100 = int(temperature * 100)
    temperature_ch.write(struct.pack("<h", t_100), send_update=True)

    # BATTERY LEVEL (0x2A19) — uint8, %
    lvl = max(0, min(100, int(battery_level)))
    battery_ch.write(struct.pack("B", lvl), send_update=True)


# =========================================================
# BLE Peripheral — Advertising / Connections with whitelist / Wait for rx from Phone
# =========================================================


async def rx_task():
    global rx_value

    while True:
        conn = await rx_ch.written()
        data = rx_ch.read()       # <-- actual bytes from the phone

        if isinstance(data, (bytes, bytearray)):
            rx_value = data
            text = data.decode("utf-8", "ignore").strip()
            print("RX DATA =", text)

            def parse_float(token):
                try:
                    return float(token)
                except Exception:
                    return 0.0

            pas_val = ""
            speed_val = 0.0
            c_range_val = 0.0
            dist_val = 0.0

            if text:
                parts = [p.strip() for p in text.split(",")]
                if len(parts) >= 1:
                    pas_val = parts[0]
                if len(parts) >= 2:
                    speed_val = parse_float(parts[1])
                if len(parts) >= 3:
                    c_range_val = parse_float(parts[2])
                if len(parts) >= 4:
                    dist_val = parse_float(parts[3])

            # UPDATE DISPLAY SHARED VALUE
            sensor_data["pas"] = pas_val
            sensor_data["speed"] = speed_val
            sensor_data["c_range"] = c_range_val
            sensor_data["dist"] = dist_val

        await asyncio.sleep(0.1)


async def peripheral_task():
    global _authorized_peer

    while True:
        try:
            # Advertise so phone can see "EBikeSensor"
            async with await aioble.advertise(
                interval_us=_ADV_INTERVAL_US,
                name="EBikeSensor",
                services=[_BAT_SERV_UUID],
                appearance=_ADV_APPEARANCE_GENERIC_SENSOR,
            ) as connection:
                dev = connection.device
                peer = _format_peer(dev)
                print("Incoming connection from:", peer)

                # First ever connection → treat as owner
                if _authorized_peer is None:
                    _authorized_peer = peer
                    print("Authorized device set to:", _authorized_peer)
                else:
                    # Already have an owner: only allow that one
                    if peer != _authorized_peer:
                        print("Unauthorized device, disconnecting.")
                        await connection.disconnect()
                        await asyncio.sleep_ms(100)
                        continue

                sensor_data["connected"] = True
                try:
                    print("Authorized device connected, awaiting disconnect...")
                    await connection.disconnected()
                    print("Authorized device disconnected.")
                finally:
                    sensor_data["connected"] = False

        except Exception as exc:
            print("BLE peripheral error:", exc)
       
       # Global variable updated by BLE writes
        rx_value = None  


        # Small pause before re-advertising
        await asyncio.sleep_ms(100)
